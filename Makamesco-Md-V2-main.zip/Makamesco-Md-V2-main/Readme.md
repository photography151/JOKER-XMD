

# JOKER-MD-V.2

<h3 align="center">"..STAY ON TRACK EVERYONE IS..MAD..."</h3>

<div align="center">
  <img src="https://files.catbox.moe/sigghy.jpg" alt="JOKER-MD-V.2 Banner" width="400" />
  
  <hr style="width: 80%; margin: 20px auto; border: 0.5px solid #333;" />
</div>



<table align="center">
  <tr>
    <td align="center" width="50%">
      <h3>Fork Repository</h3>
      <p>Customize the bot for your needs</p>
      <a href="https://github.com/sesco001/Makamesco-Md-V2/fork">
        <img src="https://img.shields.io/badge/FORK-purple?style=for-the-badge" alt="Fork Button">
      </a>
    </td>
    <td align="center" width="50%">
      <h3>Pair Session</h3>
      <p>Link your session ID to start using</p>
      <a href="https://makamesco-md-code.onrender.com/">
        <img src="https://img.shields.io/badge/Pair_Session-white?style=for-the-badge" alt="Pair Session">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" width="50%">
      <h3>Social media boosting Website</h3>
      <p>Visit followers increase and all boost site</p>
      <a href="https://makamescodigitalsolutions.com/">
        <img src="https://img.shields.io/badge/Website-ff69b4?style=for-the-badge" alt="Official Website">
      </a>
    </td>
    <td align="center" width="50%">
      <h3>Contact Developer</h3>
      <p>Get in touch with creator for deployment</p>
      <a href="https://wa.me/+2540739285768?text=I_need_bot_Sir_ill_pay">
        <img src="https://img.shields.io/badge/Contact-green?style=for-the-badge" alt="Contact Developer">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center" width="50%">
      <h3>Deploy on render</h3>
      <p>DEPLOY RENDER</p>
      <a href="https://render.com/">
        <img src="https://img.shields.io/badge/Render-blue?style=for-the-badge" alt="DIGITEX APIs">
      </a>
    </td>
    <td align="center" width="50%">
      <h3>Deploy</h3>
      <p>Deploy to your preferred platform</p>
      <a href='https://dashboard.heroku.com/new?template=https://github.com/sesco001/Makamesco-Md-V2?tab=readme-ov-file' target="_blank"> <img title="DEPLOY DIGITEX-XMD BOT" src="https://img.shields.io/badge/👻_DEPLOY_ON_HEROKU-000000?style=for-the-badge&logo=heroku&logoColor=white&color=FF00FF" width="260" height="50"/>
      </a>
    </td>
  </tr>
</table>



<p align="center">
  <i>DEPLOY OUR BOT BOOST FOLLOWERSUSING OUR SITE I WILL ADD FEATURES."</i>
</p>

<div align="center">
  <h3>Our Supporters</h3>
  
  <a href="https://github.com/Digitex/DIGITEX-XMD/stargazers">
    <img src="http://reporoster.com/stars/dark/DIGITEXMEDIA/2FDigitexmedia-XMD" alt="Stargazers">
  </a>
  
  <a href="https://github.com/Digitexmedia/DIGITEX-XMD/network/members">
    <img src="http://reporoster.com/forks/dark/Digitexmedia/DIGITEX-XMD" alt="Forks">
  </a>
</div>
